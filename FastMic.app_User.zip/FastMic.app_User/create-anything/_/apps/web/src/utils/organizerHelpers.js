export function formatTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

export function prepareAnalyticsData(participants, questions) {
  return {
    participantsChart: [
      { name: "09:00", participants: 12 },
      { name: "09:30", participants: 28 },
      { name: "10:00", participants: 45 },
      { name: "10:30", participants: participants.length || 52 },
      { name: "11:00", participants: participants.length + 3 || 55 },
    ],
    questionsStats: [
      {
        name: "Oczekujące",
        value: questions.filter((q) => q.status === "pending").length,
        color: "#f59e0b",
      },
      {
        name: "Zatwierdzone",
        value: questions.filter((q) => q.status === "approved").length,
        color: "#10b981",
      },
      {
        name: "Odpowiedziane",
        value: questions.filter((q) => q.status === "answered").length,
        color: "#6366f1",
      },
    ],
    engagementData: [
      {
        name: "Słuchacze",
        value: participants.filter((p) => p.role === "listener").length,
      },
      {
        name: "Uczestnicy",
        value: participants.filter((p) => p.role === "participant").length,
      },
      {
        name: "Moderatorzy",
        value: participants.filter((p) => p.role === "organizer").length,
      },
    ],
  };
}
