import { toast } from "sonner";

export async function approveQuestion(questionId) {
  try {
    const response = await fetch(`/api/questions/${questionId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "approved" }),
    });
    if (response.ok) {
      toast.success("✅ Pytanie zatwierdzone");
    }
  } catch (error) {
    toast.error("Błąd zatwierdzania");
  }
}

export async function declineQuestion(questionId) {
  try {
    const response = await fetch(`/api/questions/${questionId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "declined" }),
    });
    if (response.ok) {
      toast.success("❌ Pytanie odrzucone");
    }
  } catch (error) {
    toast.error("Błąd odrzucania");
  }
}

export async function markAsAnswered(questionId) {
  try {
    const response = await fetch(`/api/questions/${questionId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        status: "answered",
        answered_at: new Date().toISOString(),
      }),
    });
    if (response.ok) {
      toast.success("✅ Oznaczono jako odpowiedziane");
    }
  } catch (error) {
    toast.error("Błąd oznaczania");
  }
}
