import { Mic, Square, Loader } from "lucide-react";

export function RecordingButton({
  isRecording,
  isProcessing,
  onStart,
  onStop,
}) {
  return (
    <div className="text-center mb-8">
      <button
        onClick={isRecording ? onStop : onStart}
        disabled={isProcessing}
        className={`w-32 h-32 rounded-full flex items-center justify-center text-white font-bold transition-all duration-300 transform hover:scale-105 shadow-2xl ${
          isRecording
            ? "bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700"
            : isProcessing
              ? "bg-gradient-to-r from-gray-400 to-gray-500"
              : "bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700"
        }`}
      >
        {isProcessing ? (
          <Loader className="h-8 w-8 animate-spin" />
        ) : isRecording ? (
          <Square className="h-8 w-8" />
        ) : (
          <Mic className="h-8 w-8" />
        )}
      </button>
    </div>
  );
}
