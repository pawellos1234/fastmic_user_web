import { Hand } from "lucide-react";

export function SpeakerQueue({ questions }) {
  const approvedQuestions = questions
    .filter((q) => q.status === "approved")
    .slice(0, 3);

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-100">
      <h4 className="font-semibold text-gray-800 mb-3 flex items-center space-x-2">
        <Hand className="h-5 w-5 text-indigo-600" />
        <span>Kolejka do głosu</span>
      </h4>
      <div className="space-y-2">
        {approvedQuestions.map((question, index) => (
          <div
            key={question.id}
            className="flex items-center space-x-3 p-2 bg-white/50 rounded-lg"
          >
            <div className="w-6 h-6 bg-indigo-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
              {index + 1}
            </div>
            <div className="flex-1">
              <p className="font-medium text-gray-800">
                {question.participant_name}
              </p>
              <p className="text-sm text-gray-600 truncate">
                {question.question_text}
              </p>
            </div>
          </div>
        ))}
        {approvedQuestions.length === 0 && (
          <p className="text-gray-500 text-center py-4">
            Brak zatwierdzonych pytań
          </p>
        )}
      </div>
    </div>
  );
}
