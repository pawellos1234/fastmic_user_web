import { TrendingUp, CheckCircle, Clock, Sparkles } from "lucide-react";
import { formatTime } from "@/utils/organizerHelpers";

export function KeyMetrics({
  participants,
  questions,
  recordingTime,
  transcriptionsCount,
}) {
  const engagementRate = Math.round(
    (questions.length / Math.max(participants.length, 1)) * 100,
  );
  const answeredCount = questions.filter((q) => q.status === "answered").length;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
        <div className="flex items-center space-x-2">
          <TrendingUp className="h-5 w-5 text-blue-600" />
          <span className="text-sm font-medium text-blue-700">
            Zaangażowanie
          </span>
        </div>
        <p className="text-2xl font-bold text-blue-600 mt-1">
          {engagementRate}%
        </p>
      </div>

      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100">
        <div className="flex items-center space-x-2">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <span className="text-sm font-medium text-green-700">Odpowiedzi</span>
        </div>
        <p className="text-2xl font-bold text-green-600 mt-1">
          {answeredCount}
        </p>
      </div>

      <div className="bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl p-4 border border-yellow-100">
        <div className="flex items-center space-x-2">
          <Clock className="h-5 w-5 text-yellow-600" />
          <span className="text-sm font-medium text-yellow-700">
            Czas sesji
          </span>
        </div>
        <p className="text-2xl font-bold text-yellow-600 mt-1">
          {formatTime(recordingTime)}
        </p>
      </div>

      <div className="bg-gradient-to-r from-purple-50 to-violet-50 rounded-xl p-4 border border-purple-100">
        <div className="flex items-center space-x-2">
          <Sparkles className="h-5 w-5 text-purple-600" />
          <span className="text-sm font-medium text-purple-700">
            AI Transkrypcje
          </span>
        </div>
        <p className="text-2xl font-bold text-purple-600 mt-1">
          {transcriptionsCount}
        </p>
      </div>
    </div>
  );
}
