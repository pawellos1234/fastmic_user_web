export function AudioLevelMeter({ audioLevel }) {
  return (
    <div className="mb-6">
      <div className="w-full bg-gray-200 rounded-full h-3">
        <div
          className="bg-gradient-to-r from-green-400 via-yellow-400 to-red-500 h-3 rounded-full transition-all duration-200"
          style={{ width: `${audioLevel}%` }}
        ></div>
      </div>
      <p className="text-center text-sm text-gray-600 mt-2">
        Poziom audio: {Math.round(audioLevel)}%
      </p>
    </div>
  );
}
