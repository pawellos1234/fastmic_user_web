import { Mic, BarChart3, MessageSquare } from "lucide-react";

export function TabNavigation({
  activeTab,
  onTabChange,
  pendingQuestionsCount,
}) {
  return (
    <div className="flex border-b border-indigo-100">
      <button
        onClick={() => onTabChange("recording")}
        className={`flex-1 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
          activeTab === "recording"
            ? "border-indigo-500 text-indigo-600 bg-indigo-50/50"
            : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50/50"
        }`}
      >
        <div className="flex items-center justify-center space-x-2">
          <Mic className="h-4 w-4" />
          <span>Nagrywanie</span>
        </div>
      </button>
      <button
        onClick={() => onTabChange("analytics")}
        className={`flex-1 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
          activeTab === "analytics"
            ? "border-indigo-500 text-indigo-600 bg-indigo-50/50"
            : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50/50"
        }`}
      >
        <div className="flex items-center justify-center space-x-2">
          <BarChart3 className="h-4 w-4" />
          <span>Analityki</span>
        </div>
      </button>
      <button
        onClick={() => onTabChange("questions")}
        className={`flex-1 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
          activeTab === "questions"
            ? "border-indigo-500 text-indigo-600 bg-indigo-50/50"
            : "border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50/50"
        }`}
      >
        <div className="flex items-center justify-center space-x-2">
          <MessageSquare className="h-4 w-4" />
          <span>Pytania ({pendingQuestionsCount})</span>
        </div>
      </button>
    </div>
  );
}
