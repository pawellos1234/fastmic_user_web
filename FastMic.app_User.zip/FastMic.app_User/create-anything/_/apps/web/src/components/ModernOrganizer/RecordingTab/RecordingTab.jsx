import { RecordingButton } from "./RecordingButton";
import { AudioLevelMeter } from "./AudioLevelMeter";
import { RecordingStatus } from "./RecordingStatus";
import { TranscriptionDisplay } from "./TranscriptionDisplay";

export function RecordingTab({
  isRecording,
  isProcessing,
  recordingTime,
  audioLevel,
  currentTranscription,
  currentTranslation,
  transcriptions,
  onStartRecording,
  onStopRecording,
}) {
  return (
    <div>
      <RecordingButton
        isRecording={isRecording}
        isProcessing={isProcessing}
        onStart={onStartRecording}
        onStop={onStopRecording}
      />

      {isRecording && <AudioLevelMeter audioLevel={audioLevel} />}

      <RecordingStatus
        isProcessing={isProcessing}
        isRecording={isRecording}
        recordingTime={recordingTime}
      />

      <TranscriptionDisplay
        currentTranscription={currentTranscription}
        currentTranslation={currentTranslation}
        transcriptions={transcriptions}
      />
    </div>
  );
}
