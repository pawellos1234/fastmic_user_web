export function TranscriptionDisplay({
  currentTranscription,
  currentTranslation,
  transcriptions,
}) {
  return (
    <div>
      <h3 className="text-lg font-bold text-gray-800 mb-4">
        Transkrypcja na żywo
      </h3>

      {currentTranscription && (
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 border border-indigo-100 mb-4">
          <p className="text-gray-800 font-medium mb-2">
            {currentTranscription}
          </p>
          {currentTranslation && (
            <p className="text-gray-600 italic text-sm border-t border-indigo-200 pt-2">
              {currentTranslation}
            </p>
          )}
        </div>
      )}

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {transcriptions.map((item) => (
          <div
            key={item.id}
            className="bg-white/50 rounded-xl p-3 border border-gray-100"
          >
            <p className="text-xs text-gray-500 mb-1">
              {item.timestamp.toLocaleTimeString("pl-PL")}
            </p>
            <p className="text-sm text-gray-800">{item.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
