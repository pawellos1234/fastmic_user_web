import { MessageSquare } from "lucide-react";
import { QuestionCard } from "./QuestionCard";
import { SpeakerQueue } from "./SpeakerQueue";

export function QuestionsTab({
  questions,
  onApprove,
  onDecline,
  onMarkAnswered,
}) {
  const pendingCount = questions.filter((q) => q.status === "pending").length;
  const approvedCount = questions.filter((q) => q.status === "approved").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold text-gray-800">
          Zarządzanie pytaniami
        </h3>
        <div className="flex space-x-2 text-sm">
          <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-lg">
            {pendingCount} oczekujących
          </span>
          <span className="px-2 py-1 bg-green-100 text-green-700 rounded-lg">
            {approvedCount} zatwierdzonych
          </span>
        </div>
      </div>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {questions.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MessageSquare className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Brak pytań od uczestników</p>
          </div>
        ) : (
          questions.map((question) => (
            <QuestionCard
              key={question.id}
              question={question}
              onApprove={onApprove}
              onDecline={onDecline}
              onMarkAnswered={onMarkAnswered}
            />
          ))
        )}
      </div>

      <SpeakerQueue questions={questions} />
    </div>
  );
}
