import { ArrowLeft } from "lucide-react";
import FastMicLogo from "@/components/FastMicLogo";

export function Header({
  selectedEvent,
  events,
  onEventChange,
  language,
  onLanguageChange,
}) {
  return (
    <nav className="bg-white/70 backdrop-blur-xl border-b border-indigo-100/50 sticky top-0 z-50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="flex justify-between items-center h-16">
          <button
            onClick={() => (window.location.href = "/")}
            className="flex items-center space-x-2 text-gray-600 hover:text-indigo-600 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          <FastMicLogo />

          <div className="flex items-center space-x-4">
            <select
              value={selectedEvent?.id || ""}
              onChange={(e) => {
                const event = events.find(
                  (ev) => ev.id === parseInt(e.target.value),
                );
                onEventChange(event);
              }}
              className="px-3 py-2 rounded-xl bg-white/50 border border-indigo-200 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Wybierz wydarzenie</option>
              {events.map((event) => (
                <option key={event.id} value={event.id}>
                  {event.title} ({event.code})
                </option>
              ))}
            </select>

            <select
              value={language}
              onChange={(e) => onLanguageChange(e.target.value)}
              className="px-3 py-2 rounded-xl bg-white/50 border border-indigo-200 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="pl">Polski</option>
              <option value="en">English</option>
              <option value="de">Deutsch</option>
              <option value="fr">Français</option>
            </select>
          </div>
        </div>
      </div>
    </nav>
  );
}
