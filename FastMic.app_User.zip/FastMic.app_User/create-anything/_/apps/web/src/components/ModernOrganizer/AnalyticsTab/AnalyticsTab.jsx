import { ParticipantsChart } from "./ParticipantsChart";
import { QuestionsStatsChart } from "./QuestionsStatsChart";
import { EngagementChart } from "./EngagementChart";
import { KeyMetrics } from "./KeyMetrics";

export function AnalyticsTab({
  analyticsData,
  participants,
  questions,
  recordingTime,
  transcriptionsCount,
}) {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-gray-800">Analityki Wydarzenia</h3>

      <ParticipantsChart data={analyticsData.participantsChart} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <QuestionsStatsChart data={analyticsData.questionsStats} />
        <EngagementChart data={analyticsData.engagementData} />
      </div>

      <KeyMetrics
        participants={participants}
        questions={questions}
        recordingTime={recordingTime}
        transcriptionsCount={transcriptionsCount}
      />
    </div>
  );
}
