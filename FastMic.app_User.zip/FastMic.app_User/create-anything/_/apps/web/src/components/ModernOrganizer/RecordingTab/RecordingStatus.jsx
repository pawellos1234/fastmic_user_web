import { Loader } from "lucide-react";
import { formatTime } from "@/utils/organizerHelpers";

export function RecordingStatus({ isProcessing, isRecording, recordingTime }) {
  return (
    <div className="text-center mb-6">
      <p className="text-lg font-medium text-gray-700">
        {isProcessing ? (
          <span className="flex items-center justify-center space-x-2">
            <Loader className="h-5 w-5 animate-spin" />
            <span>Przetwarzanie z OpenAI Whisper...</span>
          </span>
        ) : isRecording ? (
          <span className="text-red-600">
            🔴 Na żywo - {formatTime(recordingTime)}
          </span>
        ) : (
          <span className="text-gray-500">Gotowy do nagrywania</span>
        )}
      </p>
    </div>
  );
}
