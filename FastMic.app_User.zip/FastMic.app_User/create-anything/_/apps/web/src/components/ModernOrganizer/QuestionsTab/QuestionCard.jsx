import { CheckCircle, XCircle } from "lucide-react";

export function QuestionCard({
  question,
  onApprove,
  onDecline,
  onMarkAnswered,
}) {
  const getStatusBadge = () => {
    if (question.status === "pending") {
      return (
        <span className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full">
          Nowe
        </span>
      );
    }
    if (question.status === "approved") {
      return (
        <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
          Zatwierdzone
        </span>
      );
    }
    if (question.status === "answered") {
      return (
        <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
          Odpowiedziane
        </span>
      );
    }
    return null;
  };

  const getBorderClass = () => {
    if (question.status === "pending")
      return "border-yellow-200 bg-yellow-50/50";
    if (question.status === "approved")
      return "border-green-200 bg-green-50/50";
    if (question.status === "answered") return "border-blue-200 bg-blue-50/50";
    return "border-gray-200";
  };

  return (
    <div className={`bg-white/50 rounded-xl p-4 border ${getBorderClass()}`}>
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <span className="font-medium text-gray-800">
              {question.participant_name}
            </span>
            {getStatusBadge()}
          </div>
          <p className="text-sm text-gray-600 mb-2">
            {question.participant_email}
          </p>
          <p className="text-gray-800">{question.question_text}</p>
          <p className="text-xs text-gray-500 mt-2">
            Przesłane: {new Date(question.submitted_at).toLocaleString("pl-PL")}
          </p>
        </div>
      </div>

      {question.status === "pending" && (
        <div className="flex space-x-2">
          <button
            onClick={() => onApprove(question.id)}
            className="flex items-center space-x-1 px-3 py-1 bg-green-500 hover:bg-green-600 text-white text-sm rounded-lg transition-colors"
          >
            <CheckCircle className="h-4 w-4" />
            <span>Zatwierdź</span>
          </button>
          <button
            onClick={() => onDecline(question.id)}
            className="flex items-center space-x-1 px-3 py-1 bg-red-500 hover:bg-red-600 text-white text-sm rounded-lg transition-colors"
          >
            <XCircle className="h-4 w-4" />
            <span>Odrzuć</span>
          </button>
        </div>
      )}

      {question.status === "approved" && (
        <div className="flex space-x-2">
          <button
            onClick={() => onMarkAnswered(question.id)}
            className="flex items-center space-x-1 px-3 py-1 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded-lg transition-colors"
          >
            <CheckCircle className="h-4 w-4" />
            <span>Oznacz jako odpowiedziane</span>
          </button>
          <button
            onClick={() => onDecline(question.id)}
            className="flex items-center space-x-1 px-3 py-1 bg-gray-500 hover:bg-gray-600 text-white text-sm rounded-lg transition-colors"
          >
            <XCircle className="h-4 w-4" />
            <span>Anuluj</span>
          </button>
        </div>
      )}
    </div>
  );
}
