import { Clock, Users, MessageSquare, Activity } from "lucide-react";
import { formatTime } from "@/utils/organizerHelpers";

export function StatsDashboard({
  recordingTime,
  participantsCount,
  pendingQuestionsCount,
  audioLevel,
}) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="bg-white/60 backdrop-blur-xl rounded-2xl p-4 border border-indigo-100/50 text-center">
        <Clock className="h-6 w-6 text-indigo-500 mx-auto mb-2" />
        <p className="text-lg font-bold text-indigo-600">
          {formatTime(recordingTime)}
        </p>
        <p className="text-xs text-gray-500">Czas nagrania</p>
      </div>
      <div className="bg-white/60 backdrop-blur-xl rounded-2xl p-4 border border-green-100/50 text-center">
        <Users className="h-6 w-6 text-green-500 mx-auto mb-2" />
        <p className="text-lg font-bold text-green-600">{participantsCount}</p>
        <p className="text-xs text-gray-500">Uczestników</p>
      </div>
      <div className="bg-white/60 backdrop-blur-xl rounded-2xl p-4 border border-orange-100/50 text-center">
        <MessageSquare className="h-6 w-6 text-orange-500 mx-auto mb-2" />
        <p className="text-lg font-bold text-orange-600">
          {pendingQuestionsCount}
        </p>
        <p className="text-xs text-gray-500">Nowe pytania</p>
      </div>
      <div className="bg-white/60 backdrop-blur-xl rounded-2xl p-4 border border-purple-100/50 text-center">
        <Activity className="h-6 w-6 text-purple-500 mx-auto mb-2" />
        <p className="text-lg font-bold text-purple-600">
          {Math.round(audioLevel)}%
        </p>
        <p className="text-xs text-gray-500">Poziom audio</p>
      </div>
    </div>
  );
}
