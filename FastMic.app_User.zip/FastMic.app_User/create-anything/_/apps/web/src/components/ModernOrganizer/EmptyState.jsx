import { FastMicLogoHero } from "@/components/FastMicLogo";

export function EmptyState() {
  return (
    <div className="flex items-center justify-center h-[80vh]">
      <div className="text-center">
        <div className="mb-6">
          <FastMicLogoHero className="justify-center" />
        </div>
        <h2 className="text-xl font-bold text-gray-800 mb-2">
          Wybierz wydarzenie
        </h2>
        <p className="text-gray-500">Rozpocznij transkrypcję na żywo</p>
      </div>
    </div>
  );
}
