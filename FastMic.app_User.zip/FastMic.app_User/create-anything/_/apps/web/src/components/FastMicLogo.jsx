import { Mic } from "lucide-react";

export default function FastMicLogo({
  variant = "primary",
  size = "normal",
  className = "",
  ...props
}) {
  const baseClasses = "flex items-center space-x-2";

  const iconSize = {
    small: "h-6 w-6",
    normal: "h-8 w-8",
    large: "h-8 w-8",
    hero: "h-12 w-12",
  }[size];

  const iconColor = variant === "dark" ? "text-blue-400" : "text-blue-600";

  const textSize = {
    small: "text-lg",
    normal: "text-xl",
    large: "text-2xl",
    hero: "text-4xl",
  }[size];

  const textColor = variant === "dark" ? "text-white" : "text-gray-900";

  return (
    <div className={`${baseClasses} ${className}`} {...props}>
      <Mic className={`${iconSize} ${iconColor}`} />
      <span className={`${textSize} font-bold ${textColor}`}>FastMic</span>
    </div>
  );
}

// Named exports for convenience
export const FastMicLogoSmall = (props) => (
  <FastMicLogo size="small" {...props} />
);
export const FastMicLogoLarge = (props) => (
  <FastMicLogo size="large" {...props} />
);
export const FastMicLogoHero = (props) => (
  <FastMicLogo size="hero" {...props} />
);
export const FastMicLogoDark = (props) => (
  <FastMicLogo variant="dark" {...props} />
);
