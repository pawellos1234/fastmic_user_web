import {
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export function QuestionsStatsChart({ data }) {
  return (
    <div className="bg-white/50 rounded-xl p-4 border border-indigo-100">
      <h4 className="font-semibold text-gray-700 mb-3">Status pytań</h4>
      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <RechartsPieChart>
            <Pie
              dataKey="value"
              data={data}
              cx="50%"
              cy="50%"
              outerRadius={60}
              label={({ name, value }) =>
                value > 0 ? `${name}: ${value}` : ""
              }
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip />
          </RechartsPieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
