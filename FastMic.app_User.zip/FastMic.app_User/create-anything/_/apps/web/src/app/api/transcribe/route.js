export async function POST(request) {
  try {
    const formData = await request.formData();
    const audioFile = formData.get("audio");

    if (!audioFile) {
      return Response.json(
        { error: "No audio file provided" },
        { status: 400 },
      );
    }

    // Create form data for OpenAI Whisper
    const openAIFormData = new FormData();
    openAIFormData.append("file", audioFile);
    openAIFormData.append("model", "whisper-1");
    openAIFormData.append("language", formData.get("language") || "pl");
    openAIFormData.append("response_format", "json");
    openAIFormData.append("timestamp_granularities[]", "word");

    // Call OpenAI Whisper API
    const response = await fetch(
      "https://api.openai.com/v1/audio/transcriptions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: openAIFormData,
      },
    );

    if (!response.ok) {
      const error = await response.text();
      console.error("OpenAI Whisper error:", error);
      return Response.json(
        { error: "Transcription failed", details: error },
        { status: response.status },
      );
    }

    const transcription = await response.json();

    return Response.json({
      success: true,
      text: transcription.text,
      words: transcription.words || [],
      language: transcription.language,
      duration: transcription.duration,
    });
  } catch (error) {
    console.error("Transcription error:", error);
    return Response.json(
      { error: "Internal server error", details: error.message },
      { status: 500 },
    );
  }
}
