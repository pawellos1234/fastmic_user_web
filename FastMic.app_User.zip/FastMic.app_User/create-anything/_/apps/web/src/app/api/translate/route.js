export async function POST(request) {
  try {
    const { text, targetLanguage, sourceLanguage } = await request.json();

    if (!text || !targetLanguage) {
      return Response.json(
        { error: "Text and target language are required" },
        { status: 400 },
      );
    }

    // Call ChatGPT for translation
    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: `You are a professional translator. Translate the given text from ${sourceLanguage || "auto-detect"} to ${targetLanguage}. Return only the translated text without any explanations or additional comments.`,
          },
          {
            role: "user",
            content: text,
          },
        ],
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("Translation error:", error);
      return Response.json(
        { error: "Translation failed", details: error },
        { status: response.status },
      );
    }

    const result = await response.json();
    const translatedText = result.choices[0]?.message?.content;

    if (!translatedText) {
      return Response.json(
        { error: "No translation received" },
        { status: 500 },
      );
    }

    return Response.json({
      success: true,
      originalText: text,
      translatedText,
      targetLanguage,
      sourceLanguage: sourceLanguage || "auto",
    });
  } catch (error) {
    console.error("Translation error:", error);
    return Response.json(
      { error: "Internal server error", details: error.message },
      { status: 500 },
    );
  }
}
