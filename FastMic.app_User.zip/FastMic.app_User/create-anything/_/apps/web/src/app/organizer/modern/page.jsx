"use client";

import { useState, useEffect } from "react";
import { useOrganizerEvents } from "@/hooks/useOrganizerEvents";
import { useEventQuestions } from "@/hooks/useEventQuestions";
import { useEventParticipants } from "@/hooks/useEventParticipants";
import { useAudioRecording } from "@/hooks/useAudioRecording";
import { useTranscription } from "@/hooks/useTranscription";
import { prepareAnalyticsData } from "@/utils/organizerHelpers";
import {
  approveQuestion,
  declineQuestion,
  markAsAnswered,
} from "@/utils/questionActions";
import { Header } from "@/components/ModernOrganizer/Header";
import { EmptyState } from "@/components/ModernOrganizer/EmptyState";
import { StatsDashboard } from "@/components/ModernOrganizer/StatsDashboard";
import { TabNavigation } from "@/components/ModernOrganizer/TabNavigation";
import { RecordingTab } from "@/components/ModernOrganizer/RecordingTab/RecordingTab";
import { AnalyticsTab } from "@/components/ModernOrganizer/AnalyticsTab/AnalyticsTab";
import { QuestionsTab } from "@/components/ModernOrganizer/QuestionsTab/QuestionsTab";

export default function ModernOrganizerPage() {
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [language, setLanguage] = useState("pl");
  const [activeTab, setActiveTab] = useState("recording");

  // Fetch data
  const { data: events = [] } = useOrganizerEvents();
  const { data: questions = [] } = useEventQuestions(selectedEvent?.id);
  const { data: participants = [] } = useEventParticipants(selectedEvent?.id);

  // Recording and transcription
  const {
    isRecording,
    recordingTime,
    audioLevel,
    isProcessing,
    setIsProcessing,
    startRecording,
    stopRecording,
  } = useAudioRecording();

  const {
    currentTranscription,
    currentTranslation,
    transcriptions,
    processAudio,
  } = useTranscription();

  // Auto-select first event
  useEffect(() => {
    if (events.length > 0 && !selectedEvent) {
      setSelectedEvent(events[0]);
    }
  }, [events, selectedEvent]);

  // Handle recording
  const handleStartRecording = () => {
    startRecording((audioBlob) => {
      setIsProcessing(true);
      processAudio(audioBlob, language, () => {
        setIsProcessing(false);
      });
    });
  };

  // Analytics data
  const analyticsData = prepareAnalyticsData(participants, questions);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <Header
        selectedEvent={selectedEvent}
        events={events}
        onEventChange={setSelectedEvent}
        language={language}
        onLanguageChange={setLanguage}
      />

      {!selectedEvent ? (
        <EmptyState />
      ) : (
        <div className="max-w-4xl mx-auto px-6 py-8">
          <StatsDashboard
            recordingTime={recordingTime}
            participantsCount={participants.length}
            pendingQuestionsCount={
              questions.filter((q) => q.status === "pending").length
            }
            audioLevel={audioLevel}
          />

          <div className="bg-white/70 backdrop-blur-xl rounded-2xl border border-indigo-100/50 mb-6">
            <TabNavigation
              activeTab={activeTab}
              onTabChange={setActiveTab}
              pendingQuestionsCount={
                questions.filter((q) => q.status === "pending").length
              }
            />

            <div className="p-6">
              {activeTab === "recording" && (
                <RecordingTab
                  isRecording={isRecording}
                  isProcessing={isProcessing}
                  recordingTime={recordingTime}
                  audioLevel={audioLevel}
                  currentTranscription={currentTranscription}
                  currentTranslation={currentTranslation}
                  transcriptions={transcriptions}
                  onStartRecording={handleStartRecording}
                  onStopRecording={stopRecording}
                />
              )}

              {activeTab === "analytics" && (
                <AnalyticsTab
                  analyticsData={analyticsData}
                  participants={participants}
                  questions={questions}
                  recordingTime={recordingTime}
                  transcriptionsCount={transcriptions.length}
                />
              )}

              {activeTab === "questions" && (
                <QuestionsTab
                  questions={questions}
                  onApprove={approveQuestion}
                  onDecline={declineQuestion}
                  onMarkAnswered={markAsAnswered}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
