"use client";

import { ArrowRight } from "lucide-react";
import { FastMicLogoHero } from "@/components/FastMicLogo";

export default function HomePage() {
  const navigateTo = (path) => {
    window.location.href = path;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <div className="min-h-screen flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          {/* Logo */}
          <div className="mb-8">
            <FastMicLogoHero className="justify-center" />
          </div>

          {/* Main Action */}
          <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-8 border border-indigo-100/50 shadow-2xl">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              Panel Organizatora
            </h1>
            <p className="text-gray-600 mb-8">
              Transkrypcja na żywo z OpenAI Whisper
            </p>

            <button
              onClick={() => navigateTo("/organizer/modern")}
              className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white py-4 px-8 rounded-2xl font-semibold transition-all duration-300 flex items-center justify-center space-x-3 transform hover:scale-105 hover:shadow-xl group"
            >
              <span className="text-lg">Rozpocznij Transkrypcję</span>
              <ArrowRight className="h-6 w-6 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
