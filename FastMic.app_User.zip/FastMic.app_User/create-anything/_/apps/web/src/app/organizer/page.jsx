"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Mic,
  Users,
  BarChart3,
  MessageSquare,
  Play,
  Pause,
  Volume2,
  Settings,
  Globe,
  ArrowLeft,
  Radio,
  Activity,
  Clock,
  Eye,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";

export default function OrganizerAudioPage() {
  const [language, setLanguage] = useState("pl");
  const [activeTab, setActiveTab] = useState("live");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const queryClient = useQueryClient();

  // Fetch events
  const { data: events = [] } = useQuery({
    queryKey: ["events"],
    queryFn: async () => {
      const response = await fetch("/api/events");
      if (!response.ok) return [];
      return response.json();
    },
    refetchInterval: 5000,
  });

  // Fetch active audio sessions
  const { data: audioSessions = [] } = useQuery({
    queryKey: ["audio-sessions", selectedEvent?.id],
    queryFn: async () => {
      if (!selectedEvent?.id) return [];
      const response = await fetch(
        `/api/audio-sessions?eventId=${selectedEvent.id}`,
      );
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!selectedEvent?.id,
    refetchInterval: 2000,
  });

  // Fetch questions/chat
  const { data: questions = [] } = useQuery({
    queryKey: ["questions", selectedEvent?.id],
    queryFn: async () => {
      if (!selectedEvent?.id) return [];
      const response = await fetch(
        `/api/questions?eventId=${selectedEvent.id}`,
      );
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!selectedEvent?.id,
    refetchInterval: 3000,
  });

  // Auto-select first event
  useEffect(() => {
    if (events.length > 0 && !selectedEvent) {
      setSelectedEvent(events[0]);
    }
  }, [events, selectedEvent]);

  // Update question status
  const updateQuestionMutation = useMutation({
    mutationFn: async ({ questionId, status }) => {
      const response = await fetch(`/api/questions/${questionId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!response.ok) throw new Error("Failed to update");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["questions", selectedEvent?.id],
      });
      toast.success("Zaktualizowano pytanie");
    },
  });

  const handleQuestionAction = (questionId, status) => {
    updateQuestionMutation.mutate({ questionId, status });
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    toast.success(
      isRecording ? "Nagrywanie zatrzymane" : "Rozpoczęto nagrywanie",
    );
  };

  const translations = {
    pl: {
      title: "Panel Audio/Video",
      live: "Na Żywo",
      analytics: "Analityka",
      chat: "Chat & Pytania",
      selectEvent: "Wybierz Wydarzenie",
      recording: "Nagrywanie",
      participants: "Uczestników",
      questions: "Pytań",
      activeTime: "Czas aktywny",
      audioLevel: "Poziom dźwięku",
      startRecording: "Rozpocznij Nagrywanie",
      stopRecording: "Zatrzymaj Nagrywanie",
      noQuestions: "Brak nowych pytań",
      approve: "Zatwierdź",
      decline: "Odrzuć",
      answered: "Odpowiedziane",
      pending: "Oczekuje",
      approved: "Zatwierdzone",
      declined: "Odrzucone",
      liveTranscription: "Transkrypcja Na Żywo",
      eventStats: "Statystyki Wydarzenia",
      audioSettings: "Ustawienia Audio",
      back: "Powrót",
    },
  };

  const t = translations[language];

  // Mock analytics data
  const analytics = {
    totalParticipants: questions.length + Math.floor(Math.random() * 50),
    activeNow: Math.floor(Math.random() * 30) + 10,
    questionsTotal: questions.length,
    recordingTime: isRecording ? "15:42" : "00:00",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <button
              onClick={() => (window.location.href = "/")}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="h-5 w-5" />
              <span>{t.back}</span>
            </button>

            <div className="flex items-center space-x-2">
              <Radio className="h-8 w-8 text-purple-600" />
              <span className="text-xl font-bold text-gray-900">{t.title}</span>
            </div>

            <div className="flex items-center space-x-4">
              {/* Event Selector */}
              <select
                value={selectedEvent?.id || ""}
                onChange={(e) => {
                  const event = events.find(
                    (ev) => ev.id === parseInt(e.target.value),
                  );
                  setSelectedEvent(event);
                }}
                className="px-3 py-2 rounded-lg bg-white/50 border border-white/30 text-sm"
              >
                <option value="">{t.selectEvent}</option>
                {events.map((event) => (
                  <option key={event.id} value={event.id}>
                    {event.title} ({event.code})
                  </option>
                ))}
              </select>

              <div className="flex items-center space-x-2 bg-white/50 px-3 py-2 rounded-lg">
                <div
                  className={`w-2 h-2 rounded-full ${isRecording ? "bg-red-500 animate-pulse" : "bg-gray-400"}`}
                ></div>
                <span className="text-sm text-gray-700">
                  {isRecording ? "LIVE" : "OFFLINE"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {!selectedEvent ? (
        <div className="max-w-7xl mx-auto px-4 py-20 text-center">
          <Radio className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-600 mb-2">
            {t.selectEvent}
          </h2>
          <p className="text-gray-500">
            Wybierz wydarzenie aby rozpocząć zarządzanie audio/video
          </p>
        </div>
      ) : (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white/60 backdrop-blur-md rounded-xl p-4 border border-white/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{t.participants}</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {analytics.totalParticipants}
                  </p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-md rounded-xl p-4 border border-white/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Aktywni Teraz</p>
                  <p className="text-2xl font-bold text-green-600">
                    {analytics.activeNow}
                  </p>
                </div>
                <Activity className="h-8 w-8 text-green-500" />
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-md rounded-xl p-4 border border-white/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{t.questions}</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {analytics.questionsTotal}
                  </p>
                </div>
                <MessageSquare className="h-8 w-8 text-purple-500" />
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-md rounded-xl p-4 border border-white/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{t.recordingTime}</p>
                  <p className="text-2xl font-bold text-red-600">
                    {analytics.recordingTime}
                  </p>
                </div>
                <Clock className="h-8 w-8 text-red-500" />
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Audio Control Panel */}
            <div className="lg:col-span-2 space-y-6">
              {/* Recording Controls */}
              <div className="bg-white/60 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center space-x-2">
                  <Mic className="h-6 w-6" />
                  <span>Kontrola Audio</span>
                </h3>

                <div className="flex items-center justify-center space-x-4 mb-6">
                  <button
                    onClick={toggleRecording}
                    className={`flex items-center space-x-2 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-200 ${
                      isRecording
                        ? "bg-red-600 hover:bg-red-700 text-white"
                        : "bg-green-600 hover:bg-green-700 text-white"
                    }`}
                  >
                    {isRecording ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6" />
                    )}
                    <span>
                      {isRecording ? t.stopRecording : t.startRecording}
                    </span>
                  </button>
                </div>

                {/* Audio Level Meter */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">
                      {t.audioLevel}
                    </span>
                    <span className="text-sm text-gray-500">85%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-4">
                    <div
                      className="bg-gradient-to-r from-green-400 via-yellow-400 to-red-500 h-4 rounded-full transition-all duration-200"
                      style={{ width: "85%" }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Live Transcription */}
              <div className="bg-white/60 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center space-x-2">
                  <Eye className="h-6 w-6" />
                  <span>{t.liveTranscription}</span>
                </h3>

                <div className="bg-gray-50 rounded-lg p-4 min-h-[200px]">
                  {isRecording ? (
                    <div className="space-y-3">
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full mt-2 animate-pulse"></div>
                        <div>
                          <p className="text-sm text-gray-600">16:42:15</p>
                          <p className="text-gray-900">
                            Witam wszystkich na dzisiejszym wydarzeniu.
                            Rozpoczynamy prezentację o nowych technologiach...
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full mt-2 animate-pulse"></div>
                        <div>
                          <p className="text-sm text-gray-600">16:43:02</p>
                          <p className="text-gray-900">
                            Proszę o pytania w aplikacji, odpowiem na nie na
                            końcu sesji...
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-500 italic text-center py-16">
                      Rozpocznij nagrywanie aby zobaczyć transkrypcję na żywo
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Chat & Questions Panel */}
            <div className="bg-white/60 backdrop-blur-md rounded-xl p-6 border border-white/20">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center space-x-2">
                <MessageSquare className="h-6 w-6" />
                <span>{t.chat}</span>
              </h3>

              <div className="space-y-4 max-h-[600px] overflow-y-auto">
                {questions.length === 0 ? (
                  <p className="text-gray-500 italic text-center py-8">
                    {t.noQuestions}
                  </p>
                ) : (
                  questions.map((question) => (
                    <div
                      key={question.id}
                      className="bg-white/50 rounded-lg p-4 border border-white/20"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-medium text-gray-900 text-sm">
                            {question.participant_name}
                          </h4>
                          <p className="text-xs text-gray-500">
                            {new Date(question.submitted_at).toLocaleTimeString(
                              "pl-PL",
                            )}
                          </p>
                        </div>
                        <span
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            question.status === "approved"
                              ? "bg-green-100 text-green-800"
                              : question.status === "declined"
                                ? "bg-red-100 text-red-800"
                                : question.status === "answered"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {t[question.status] || question.status}
                        </span>
                      </div>

                      <p className="text-gray-800 mb-3 text-sm">
                        {question.question_text}
                      </p>

                      {question.status === "pending" && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() =>
                              handleQuestionAction(question.id, "approved")
                            }
                            className="flex items-center space-x-1 px-2 py-1 bg-green-600 text-white rounded text-xs hover:bg-green-700"
                          >
                            <CheckCircle className="h-3 w-3" />
                            <span>{t.approve}</span>
                          </button>
                          <button
                            onClick={() =>
                              handleQuestionAction(question.id, "declined")
                            }
                            className="flex items-center space-x-1 px-2 py-1 bg-red-600 text-white rounded text-xs hover:bg-red-700"
                          >
                            <XCircle className="h-3 w-3" />
                            <span>{t.decline}</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
