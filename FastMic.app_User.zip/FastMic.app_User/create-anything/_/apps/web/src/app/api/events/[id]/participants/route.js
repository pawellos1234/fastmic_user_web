import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { id } = params;

    const participants = await sql`
      SELECT 
        id,
        name,
        email,
        role,
        joined_at,
        last_active
      FROM participants 
      WHERE event_id = ${id}
      ORDER BY joined_at DESC
    `;

    return Response.json(participants);
  } catch (error) {
    console.error("Error fetching participants:", error);
    return Response.json(
      { error: "Failed to fetch participants" },
      { status: 500 },
    );
  }
}
