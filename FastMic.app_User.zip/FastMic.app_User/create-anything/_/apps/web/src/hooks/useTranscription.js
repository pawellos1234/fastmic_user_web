import { useState } from "react";
import { toast } from "sonner";

export function useTranscription() {
  const [currentTranscription, setCurrentTranscription] = useState("");
  const [currentTranslation, setCurrentTranslation] = useState("");
  const [transcriptions, setTranscriptions] = useState([]);

  // Process audio with Whisper
  const processAudio = async (audioBlob, language, onComplete) => {
    try {
      const formData = new FormData();
      formData.append("audio", audioBlob, "audio.webm");
      formData.append("language", language);

      const response = await fetch("/api/transcribe", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Transcription failed");
      }

      const result = await response.json();

      if (result.success) {
        setCurrentTranscription(result.text);

        const newTranscription = {
          id: Date.now(),
          text: result.text,
          timestamp: new Date(),
          duration: result.duration || 0,
        };

        setTranscriptions((prev) => [newTranscription, ...prev].slice(0, 10));

        // Auto-translate
        if (language === "pl") {
          translateText(result.text, "English", language);
        } else {
          translateText(result.text, "Polish", language);
        }

        toast.success("✨ Transkrypcja gotowa!");

        if (onComplete) {
          onComplete();
        }
      }
    } catch (error) {
      console.error("Transcription error:", error);
      toast.error("Błąd transkrypcji");
      if (onComplete) {
        onComplete();
      }
    }
  };

  // Translate text
  const translateText = async (text, targetLang, sourceLang) => {
    try {
      const response = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text,
          targetLanguage: targetLang,
          sourceLanguage: sourceLang === "pl" ? "Polish" : "English",
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setCurrentTranslation(result.translatedText);
      }
    } catch (error) {
      console.error("Translation error:", error);
    }
  };

  return {
    currentTranscription,
    currentTranslation,
    transcriptions,
    processAudio,
  };
}
