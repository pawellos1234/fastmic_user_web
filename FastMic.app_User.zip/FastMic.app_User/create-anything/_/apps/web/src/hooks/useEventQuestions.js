import { useQuery } from "@tanstack/react-query";

export function useEventQuestions(eventId) {
  return useQuery({
    queryKey: ["questions", eventId],
    queryFn: async () => {
      if (!eventId) return [];
      const response = await fetch(`/api/questions?event_id=${eventId}`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!eventId,
    refetchInterval: 3000,
  });
}
