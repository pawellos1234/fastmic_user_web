import { useQuery } from "@tanstack/react-query";

export function useOrganizerEvents() {
  return useQuery({
    queryKey: ["events"],
    queryFn: async () => {
      const response = await fetch("/api/events");
      if (!response.ok) return [];
      return response.json();
    },
    refetchInterval: 5000,
  });
}
