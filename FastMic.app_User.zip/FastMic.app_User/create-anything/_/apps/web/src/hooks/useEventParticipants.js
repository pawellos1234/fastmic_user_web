import { useQuery } from "@tanstack/react-query";

export function useEventParticipants(eventId) {
  return useQuery({
    queryKey: ["participants", eventId],
    queryFn: async () => {
      if (!eventId) return [];
      const response = await fetch(`/api/events/${eventId}/participants`);
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!eventId,
    refetchInterval: 5000,
  });
}
